% ========================= %
% Minimum working example of using LOSP++ on a SBM graph.
% Daniel Mckenzie
% 19th June 2018
% ======================== %

clear, close all, clc
addpath(genpath('../../ThirdParty/LOSP-master/LOSP_Plus_codes'),genpath('../../Utilities'))

% ======== Parameters ============ %
n = 1e4;          % Set the number of vertices of the graph
k = 10;           % number of clusters
n0 = ceil(n/k);   % size of each cluster (equally sized)
p = (log(n))^2/n0;% in-cluster connection probability
q = 2*log(n)/n;   % between cluster connection probability
alpha = 0.5;      % random walk diffusion parameter
WalkMode = 2;     % type of random walk for LOSP++
d = 2;            % dimension of local spectral subspace
kk = 2;           % number of random walk steps

% ============= Now generate matrix and display in greyscale ============ %
A = generateA(n,n0,p,q);
Im1 = mat2gray(full(A));
imshow(imcomplement(Im1));
title('The ground truth adjacency matrix')

% ================ Randomly permute the adjacency matrix =============== %
perm = randperm(n);
A = A(perm,perm);
[~,permInv] = sort(perm);
TrueCluster = permInv(1:n0);   % the ground truth first cluster, after permutation.
Im2 = mat2gray(full(A));
figure
imshow(imcomplement(Im2));
title('The adjacency matrix, randomly permuted')

% ========================== Run SSSCP  ========================== %
Gamma = datasample(TrueCluster,3,'Replace',false); % the set of seed vertices

tic
Cluster = LOSP_Clustering(A,WalkMode,d,kk,alpha,n0,Gamma);
time = toc;

accuracy = 100*length(intersect(Cluster,TrueCluster))/n0;

NewInds = [Cluster', setdiff(1:n,Cluster)];
Anew = A(NewInds,NewInds);
Im3 = mat2gray(full(Anew));
figure
imshow(imcomplement(Im3))
title('The adjacency matrix, permuted to reveal the cluster found')

disp(['Found Cluster 1 in ', num2str(time), ' seconds, with ', num2str(accuracy), '% accuracy'])


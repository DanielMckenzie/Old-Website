% ====================================
% Test script for using HKGrow for the one cluster, weak background case.
% Daniel Mckenzie
% 20th June 2018
% ====================================

clear, close all, clc
addpath(genpath('../../Utilities'),genpath('../../ThirdParty/LOSP-master'))

% =============== Parameters ================= %
n0 = 1000;
n0vec = [n0,5000];
k = 2;
n = sum(n0vec);
p = 5*(log(n))^2/(n);% in-cluster connection probability
q = log(n)/(n);   % between cluster connection probability
P = [p,q;q,q];

% ============= Now generate matrix and display in greyscale ============ %
A = generateA2(n0vec,P);
Im1 = mat2gray(full(A));
imshow(imcomplement(Im1));
title('The ground truth adjacency matrix')

% ================ Randomly permute the adjacency matrix =============== %
perm = randperm(n);
A = A(perm,perm);
[~,permInv] = sort(perm);
TrueCluster = permInv(1:n0);   % the ground truth first cluster, after permutation.
Im2 = mat2gray(full(A));
figure
imshow(imcomplement(Im2));
title('The adjacency matrix, randomly permuted')

% ========================== Run SSSCP  ========================== %
Gamma = datasample(TrueCluster,5,'Replace',false); % the set of seed vertices

tic
[Cluster,~,~,~] = hkgrow(A,Gamma);
time = toc;

%accuracy = 100*length(intersect(Cluster,TrueCluster))/n0;
accuracy = Jaccard_Score(TrueCluster,Cluster);

NewInds = [Cluster', setdiff(1:n,Cluster)];
Anew = A(NewInds,NewInds);
Im3 = mat2gray(full(Anew));
figure
imshow(imcomplement(Im3))
title('The adjacency matrix, permuted to reveal the cluster found')

disp(['Found Cluster 1 in ', num2str(time), ' seconds, with ', num2str(accuracy), '% accuracy'])

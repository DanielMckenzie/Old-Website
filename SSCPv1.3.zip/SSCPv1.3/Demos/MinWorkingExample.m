% ========================= %
% This script demonstrates  how to use SSCP to extract a single cluster
% from a graph drawn at random from the (Symmetric) Stochastic Block Model.
% Daniel Mckenzie and Ming-Jun Lai
% June 2018
% ======================== %

addpath(genpath('../Utilities'),'../Functions')

% ======== Parameters ============ %
n = 1e4;          % Set the number of vertices of the graph
k = 10;           % number of clusters
n0 = ceil(n/k);   % size of each cluster (equally sized)
epsilon = 0.1;    % epsilon parameter
reject = 0.5;     % change this to increase/decrease probaility of false negative
p = (log(n))^2/n0;% in-cluster connection probability
q = 5*log(n)/n;   % between cluster connection probability

% ============= Now generate matrix and display in greyscale ============ %
A = generateA(n,n0,p,q);
Im1 = mat2gray(full(A));
imshow(imcomplement(Im1));
title('The ground truth adjacency matrix')

% ================ Randomly permute the adjacency matrix =============== %
perm = randperm(n);
A = A(perm,perm);
[~,permInv] = sort(perm);
TrueCluster = permInv(1:n0);   % the ground truth first cluster, after permutation.
Im2 = mat2gray(full(A));
figure
imshow(imcomplement(Im2));
title('The adjacency matrix, randomly permuted')

% ========================== Draw seed vertices =================== %
Gamma = datasample(TrueCluster,3,'Replace',false); % seed vertices

% ====================== Run SSCP ================================= %
tic
Cluster = SSCPMain(A,Gamma,n0,epsilon,reject);
time = toc;

% ================ Assess accuracy and plot ======================= %

accuracy = 100*length(intersect(Cluster,TrueCluster))/n0;
NewInds = [Cluster, setdiff(1:n,Cluster)];
Anew = A(NewInds,NewInds);
Im3 = mat2gray(full(Anew));
figure
imshow(imcomplement(Im3))
title('The adjacency matrix, permuted to reveal the cluster found')

disp(['Found Cluster 1 in ', num2str(time), ' seconds, with ', num2str(accuracy), '% accuracy'])


% ========================= %
% This script demonstrates how to use Iterated SSCP (ISSCP1) to find all
% the clusters in a graph drawn at random from the Stochastic Block Model
% Daniel Mckenzie and Ming-Jun Lai
% June 2018
%
% ======================== %

addpath(genpath('../Utilities'),'../Functions')


% ======== Parameters ============ %
n = 1e4;          % Set the number of vertices of the graph
k = 10;           % number of clusters
n0 = ceil(n/k);   % size of each cluster (equally sized)
epsilon = 0.1;    % epsilon parameter
reject = 0.5;     % change this to increase/decrease probaility of false negative
p = (log(n))^2/n0;% in-cluster connection probability
q = 2*log(n)/n;   % between cluster connection probability
g = 5;            % Number of seed vertices in each cluster.           

% ============= Now generate matrix and display in greyscale ============ %
A = generateA(n,n0,p,q);
Im1 = mat2gray(full(A));
imshow(imcomplement(Im1));
title('The ground truth adjacency matrix')

% ================ Randomly permute the adjacency matrix =============== %
perm = randperm(n);
A = A(perm,perm);
[~,permInv] = sort(perm);
Im2 = mat2gray(full(A));
figure
imshow(imcomplement(Im2));
title('The adjacency matrix, randomly permuted')

% =========== Find the ground truth clusters ======== %
TrueClusters = cell(k,1);
n0vec = n0*ones(k,1);
for a = 1:k
    Ctemp = (a-1)*n0+1:a*n0;
    TrueClusters{a} = permInv(Ctemp)';
end

% ============= Pick the seed vertices ============ %
Gamma = cell(k,1);
for a = 1:k
    Gamma{a} = datasample(TrueClusters{a},g,'Replace',false);
end

% ==================== Run ISSCP1 ======================= %
tic
Clusters = ISSCP1(A,Gamma,n0vec,epsilon,reject,0);
time = toc;

accuracy = 0;
for a = 1:k
    acc_temp = 100*length(intersect(Clusters{a},TrueClusters{a}))/n0;
    accuracy = accuracy + acc_temp;
end

av_acc = accuracy/k;

disp(['Found all Clusters in ', num2str(time), ' seconds, with an average accuracy of ', num2str(av_acc), '%'])

NewInds = Cell2Vec(Clusters);
Anew = A(NewInds,NewInds);
Im3 = mat2gray(full(Anew));
figure
imshow(imcomplement(Im3))
title('The adjacency matrix, permuted to reveal the clusters found by ISSCP1')

function c = Conductance(A,S)
%        c = Conductance(A,S)
% INPUTS 
% =========================================
% A ................. Adjacency matrix of a graph
% S ................. A subset of the vertices of said graph
%
% OUTPUT
% ==========================================
% c ................. The conductance of the set S
% 
% Daniel Mckenzie
% 22 June 2018

n = size(A,1);
Sc = setdiff(1:n,S);   % complement of S
Boundary = sum(sum(A(S,Sc)));
Vol = sum(sum(A(S,S)));

c = full(Boundary/Vol);
end
function A = CreateKNN2(X,K,r)
%        A = CreateKNN2(X,K,r)
% Create the adjacency matrix of a (weighted) K-Nearest Neighbours graph
% from data matrix X. ROWS of X are data points, considered as elements ofa
% Euclidean space. Distance is calculated using \ell_2 metric. Gaussian
% kernel is used.
% Local scaling, based on `Self-Tuning for Spectral Clustering' by
% Zelnick-Manor and Perona, is also used.
% Symmetrize by taking a product, not by adding.
% 16th April 2018
% 
% INPUT
% =========================================
% X .................... n-by-p data matrix. n data points, considered as
% points in R^p
% K .................... Number of nearest neighbours to keep.
% r .................... Local clustering parameters will be set using the
% r-th nearest neighbour
%
%OUTPUT
% =========================================
% A ................... Weighted adjacency matrix.
%
% ======== Compute Nearest Neighbours ========= %
n = size(X,1);
[N,D] = knnsearch(X,X,'K',K);
SigVec = D(:,r);
disp(['Finished computing Nearest Neighbours!','\n'])

% ======== Reshape to vectors ============ %
Jtemp1 = N(:,1:end);
Jtemp2 = Jtemp1';
J = Jtemp2(:);
clear Jtemp1 JTemp2

Itemp1 = ones(K,n);
v = 1:n;
Itemp2 = Itemp1.*v;
I = Itemp2(:);
clear Itemp1 Itemp2

Dtemp1 = D(:,1:end);
Dtemp2 = Dtemp1';
Dtemp3 = Dtemp2(:);
clear Dtemp1 Dtemp2
disp(['Finished reshaping matrices to vectors!','\n'])

% ======== Create vector of scaled distances ======= %
Sig1 = SigVec(I); 
Sig2 = SigVec(J);
Sig3 = Sig1.*Sig2;
D2 = exp(-Dtemp3.^2./Sig3);

% ======= Create Sparse Array ============== %
disp('Last thing - creating Sparse Matrix...')
Atemp = sparse(I,J,D2,n,n);
A = Atemp'*Atemp;
end


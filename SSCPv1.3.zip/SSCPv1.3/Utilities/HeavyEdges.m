function Anew = HeavyEdges(A,Gamma,weight)
%        Anew = HeavyEdges(A,Gamma)
% Implement the Heavy Edges preprocessing technique for Semi-supervised
% clustering. 
% 
% INPUT
% ============================================
% A ........................ Adjacency matrix
% Gamma .................... Cell containing labelled data, each entry in
% the cell should be a list of vertices known to be in the same cluster
% weight .................. weight to apply to new edges (5 is usually a
% good value)
% 
% OUTPUT
% ============================================
% Anew ........................ new, weighted adjacency matrix
% 

% ========== Initialization ============= %
n = size(A,1);
k = length(Gamma);


% ======= Now loop through clusters, finding edges that need to be changed
Iadd = []; Jadd = [];
Iremove = []; Jremove = []; Vremove = [];
    for a=1:k
        indstemp = setdiff(1:k,a);
        noConnections = Cell2Vec(Gamma(indstemp))';
        V2temp = zeros(size(noConnections));
        C1 = Gamma{a};
        g0 = length(C1);
        for j = 1:g0
            Jadd_temp = setdiff(C1,C1(j));
            Iadd_temp = C1(j)*ones(g0-1,1);
            Jremove_temp = noConnections;
            Vtemp1 = A(C1(j),Jremove_temp);
            [~,Jtemp2,Vtemp2] = find(Vtemp1);
            Irem_temp3 = C1(j)*ones(length(Jtemp2),1);
            Jrem_temp3 = Jremove_temp(Jtemp2);
            Iadd = [Iadd;Iadd_temp];
            Jadd = [Jadd;Jadd_temp];
            Iremove = [Iremove; Irem_temp3];
            Jremove = [Jremove; Jrem_temp3];
            Vremove = [Vremove; Vtemp2'];
        end
    end

% ========== Make Masks ======================= %
A_remove = sparse(Iremove,Jremove,Vremove,n,n);
A_add = sparse(Iadd,Jadd,weight*ones(length(Iadd),1),n,n);
 
% ================= New adjacency matrix =============== % 
Anew = A - A_remove + A_add;
        
end
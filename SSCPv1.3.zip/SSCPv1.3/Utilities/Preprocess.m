% ================================= %
% This script preprocesses the MNIST data, available at:
%       http://yann.lecun.com/exdb/mnist/
% It performs PCA, extracts the top 50 principal components, and then forms
% a K-Nearest Neighbors matrix
% It uses the `MNIST helper code', downloaded from:
%       http://ufldl.stanford.edu/wiki/index.php/Using_the_MNIST_Dataset
% Daniel Mckenzie
% 14th January 2018
% ================================ %


clear, close all, clc
addpath('../../DataSets') % Point this to where the MNIST data set is

% ========= Concatenate the training and testing data sets ========= %
images1 = loadMNISTImages('train-images-idx3-ubyte')';
labels1 = loadMNISTLabels('train-labels-idx1-ubyte');
images2 = loadMNISTImages('t10k-images.idx3-ubyte')';
labels2 = loadMNISTLabels('t10k-labels.idx1-ubyte');
images = [images1;images2];
labels = [labels1;labels2];


% ============= Extract k data points at random ================ %
%k = 2e4;
k = 7e4;
%Inds = datasample(1:70000,k,'Replace',false);
Inds = 1:k;
X = images(Inds,:);
y = labels(Inds,:);
clear images labels
TestInds = datasample(1:k,100,'Replace',false);
displayData(X(TestInds,:))


% ========== Perform PCA. Extract top 50 principal components ======== %
[COEFF, SCORE, LATENT,~,EXPLAINED,MU] = pca(X,'NumComponents', 50);
Xprime = SCORE*COEFF' + MU;
figure, displayData(Xprime(TestInds,:))

% ============= Create K-NN Adjacency Matrix ================= %
r = 7; K = 15;
A = CreateKNN2(SCORE,K,r);

% ========= (Optional) Save data into some .mat file =========== %
 save('AdjMat_70k_50_Principal_Components_K=15.mat')
% =========================================== % 
% Benchmarking SSSCP on the MNIST data set
% Daniel Mckenzie
% 21 June 2018
% =========================================== %

clear, clc, close all
addpath(genpath('../ThirdParty'),genpath('../Utilities'),'../Functions')
%addpath('../../MAT_Files')

% ============ Parameters for various algorithms ========== %
% === for SSCP
epsilon = 0.2;
reject = 0.4;
sample_frac = 0.05;  % fraction of True Cluster to sample 
num_trials = 10;
% === for LOSP_Plus
alpha = 0.1;         % random walk diffusion parameter
WalkMode = 2;        % type of random walk for LOSP++
d = 2;               % dimension of local spectral subspace
kk = 2;              % number of random walk steps

% ================= Load the data =================== %
% point script to location of preprocessed MNIST data base.
%load('AdjMat_20k_50_Principal_Components_K=15JUn28.mat')
k = 10;              % number of clusters


% =========== Find the ground truth clusters ======== %
TrueClusters = cell(k,1);
n0vec = zeros(k,1);
for a = 1:k
    Ctemp = find(y== a-1);
    TrueClusters{a} = Ctemp;
    n0vec(a) = length(Ctemp);
    
end


% ============== Define all vectors of interest =========== %
time_SSCP_vec = zeros(k,1);
time_HKGrow_vec = zeros(k,1);
time_LOSP_Plus_vec = zeros(k,1);
Jaccard_SSCP_vec = zeros(k,1);
Jaccard_HKGrow_vec = zeros(k,1);
Jaccard_LOSP_Plus_vec = zeros(k,1);


for i=1:k
    % =============== Quantities of Interest ============= %
    Jaccard_SSCP = 0;
    Jaccard_LOSP_Plus = 0;
    Jaccard_HKGrow = 0;

    time_SSCP = 0;
    time_LOSP_Plus = 0;
    time_HKGrow = 0;
    TrueCluster = TrueClusters{i};
    n0 = length(TrueCluster); 
    
    for j = 1:num_trials
        % ================ Draw Seed set =============== %
        Gamma = datasample(TrueCluster,ceil(sample_frac*n0),'Replace',false);
        

        % ================= SSSCP ================= %
        tic
        Cluster_SSSCP = SSCPMain(A,Gamma,n0,epsilon,reject);
        time_SSCP = time_SSCP + toc;
        Jaccard_SSCP = Jaccard_SSCP + Jaccard_Score(TrueCluster,Cluster_SSSCP)
        
        % ================== HKGrow =================== %
        tic
        [Cluster_HKGrow,~,~,~] = hkgrow(A,Gamma);
        time_HKGrow = time_HKGrow + toc;
        Jaccard_HKGrow = Jaccard_HKGrow + Jaccard_Score(TrueCluster,Cluster_HKGrow)
        
         % ================ LOSP++  ================ %
        tic
        Cluster_LOSP_Plus = LOSP_Clustering(A,WalkMode,2,2,alpha,n0,Gamma);
        time_LOSP_Plus = time_LOSP_Plus + toc;
        Jaccard_LOSP_Plus = Jaccard_LOSP_Plus + Jaccard_Score(TrueCluster,Cluster_LOSP_Plus)
    end
    
    time_SSCP_vec(i) = time_SSCP/num_trials;
    time_HKGrow_vec(i) = time_HKGrow/num_trials;
    time_LOSP_Plus_vec(i) = time_LOSP_Plus/num_trials;
    Jaccard_SSCP_vec(i) = Jaccard_SSCP/num_trials;
    Jaccard_HKGrow_vec(i) = Jaccard_HKGrow/num_trials;
    Jaccard_LOSP_Plus_vec(i) = Jaccard_LOSP_Plus/num_trials;
end

av_time_SSSCP = mean(time_SSCP_vec);
av_time_HKGrow = mean(time_HKGrow_vec);
av_time_LOSP_Plus = mean(time_LOSP_Plus_vec);
av_Jaccard_SSSCP = mean(Jaccard_SSCP_vec);
av_Jaccard_HKGrow = mean(Jaccard_HKGrow_vec);
av_Jaccard_LOSP_Plus = mean(Jaccard_LOSP_Plus_vec);

    
    
    
    

% ================================================
% Testing Semi-Suprevised Classification of MNIST data with SSCP
% Daniel Mckenzie
% 23 June 2018
% ================================================

clear, clc, close all
addpath(genpath('../ThirdParty'),genpath('../Utilities'),'../Functions')
addpath('../../MAT_Files')

% ============ Parameters for various algorithms ========== %
% === for SSCP
epsilon = 0.2;
reject = 0.4; 
num_trials = 1;

%sample_frac_vec = 0.05;
sample_frac_vec = [0.01,0.02,0.03,0.05,0.05];
num_sizes = length(sample_frac_vec);

% ================= Load the data =================== %
% Point script to preprocessed MNIST adjacency matrix (actual data file
% used available on request).
load('AdjMat_70k_50_Principal_Components_K=15.mat')
k = 10;              % number of clusters
n = size(A,1);
AHold = A;


% =========== Find the ground truth clusters ======== %
TrueClusters = cell(k,1);
n0vec = zeros(k,1);
for a = 1:k
    Ctemp = find(y== a-1);
    TrueClusters{a} = Ctemp;
    n0vec(a) = length(Ctemp);
    
end


% ============== Define all vectors of interest =========== %
time_SSCP_vec = zeros(num_sizes,1);
Accuracy_SSCP_vec = zeros(num_sizes,1);
Accuracy2_SSCP_vec = zeros(num_sizes,1);
% Note that Accuracy reflects accuracy before running the CleanUp routine,
% while Accuracy2 is after.


for j = 1:num_sizes
    sample_frac = sample_frac_vec(j);
    % ============== Reset quantities of interest ============ %
    Accuracy = 0;
    Accuracy2 = 0;
    time = 0;
    for i = 1:num_trials
        Gamma  = cell(k,1);
        % Randomly sample labeled data
        for a = 1:k
            Gamma{a} = datasample(TrueClusters{a},ceil(sample_frac*n0vec(a)),'Replace',false);
        end
        tic
        A = HeavyEdges(AHold,Gamma,5);
        [Clusters,ClustersFinal] = ISSCP2(A,Gamma,n0vec,epsilon,reject);
        time = time + toc;
        % Now compute the accuracy
        CorrectlyClassified = 0;
        CorrectlyClassified2 = 0;
        for a = 1:k
            CorrectlyClassified = CorrectlyClassified + length(intersect(Clusters{a},TrueClusters{a}));
            CorrectlyClassified2 = CorrectlyClassified2 + length(intersect(ClustersFinal{a},TrueClusters{a}));
            
        end
        Accuracy = Accuracy + (CorrectlyClassified/n);
        Accuracy2 = Accuracy2 + (CorrectlyClassified2/n);
    end
    time_SSCP_vec(j) = time/num_trials;
    Accuracy_SSCP_vec = Accuracy/num_trials;
    Accuracy2_SSCP_vec = Accuracy2/num_trials;
end


        
        
     
    
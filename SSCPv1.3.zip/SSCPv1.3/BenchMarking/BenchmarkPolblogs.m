% =========================================== % 
% Benchmarking SSSCP on polblogs data set
% Daniel Mckenzie
% 24 June 2018
% =========================================== %

clear, clc, close all
addpath(genpath('../ThirdParty'),genpath('../Utilities'),'../Functions')

% ============ Parameters for various algorithms ========== %
% === for SSSCP
epsilon = 0.2;
reject = 0.4;
num_trials = 10;
% === for LOSP_Plus
alpha = 0.1;         % random walk diffusion parameter
WalkMode = 2;        % type of random walk for LOSP++
d = 2;               % dimension of local spectral subspace
kk = 2;              % number of random walk steps

% =========== Load the data ===================== %
load('../PolBlogs/polblogs.mat');
A = polblogsAdjMat;
n = size(A,1);

% =========== Randomly permute the data ============== %
perm = randperm(n);
[~,permInv] = sort(perm);
A = A(perm,perm);

% =========== Specify the true clusters ============== %
TrueClusters = cell(2,1);
TrueClusters{1} = permInv(1:588);
TrueClusters{2} = permInv(589:n);
n0vec = [588,n-588];

% ======= Extract high degree vertices in true clusters ======== %
DD = sum(A,2);
I = find(DD>=10);

% ======== Specify high degree members of true clusters ======== %
TrueClustersHighDeg = cell(2,1);
TrueClustersHighDeg{1} = intersect(I,TrueClusters{1});
TrueClustersHighDeg{2} = intersect(I,TrueClusters{2});


% ============== Define all quantities of interest =========== %

Accuracy_SSCP = 0;
Accuracy_ESSC = 0;
Accuracy_LOSP_Plus = 0;
Accuracy_HKGrow = 0;

Size_Cluster_SSCP_vec = zeros(num_trials,1);
Size_Cluster_ESSC_vec = zeros(num_trials,1);
Size_Cluster_LOSP_Plus_vec = zeros(num_trials,1);
Size_Cluster_HKGrow_vec = zeros(num_trials,1);

num_true_successes_ESSC = 0;

time_SSCP = 0;
time_ESSC = 0;
time_LOSP_Plus = 0;
time_HKGrow = 0;

% =================== Set to 1 for liberal, 2 for conservative ======== %
TrueCluster = TrueClusters{2};
TrueClusterHighDeg = TrueClustersHighDeg{2};
n0 = n0vec(2);
n0 = 75;

for j = 1:num_trials
    % ================ Draw Seed sets =============== %
    Gamma10 = datasample(TrueClusterHighDeg,10,'Replace',false);
    Degs_in_cluster = sum(A(TrueCluster,:),2);
    [~,Gamma1] = max(Degs_in_cluster); 
    Gam_NBD = find(A(Gamma1,:));


    % ================= SSSCP ================= %
    tic
    Cluster_SSCP = SSCPMain(A,Gamma10,n0,epsilon,reject);
    time_SSCP = time_SSCP + toc;
    Accuracy_SSCP =Accuracy_SSCP + Conductance(A,Cluster_SSCP)
    Size_Cluster_SSCP_vec(j) = length(Cluster_SSCP);


        % ============= ESSC ==================== %
       tic
       Cluster_ESSC  = ESSC(A,Gamma10,0.05);
       time_ESSC = time_ESSC + toc;
       Size_Cluster_ESSC_vec(j) = length(Cluster_ESSC);
       Accuracy_ESSC =Accuracy_ESSC + Conductance(A,Cluster_ESSC)
      

    % ================== HKGrow =================== %
    tic
    [Cluster_HKGrow,~,~,~] = hkgrow(A,Gamma10);
    time_HKGrow = time_HKGrow + toc;
   %Accuracy_HKGrow =Accuracy_HKGrow +Accuracy_Score(Cluster_HKGrow,TrueCluster)
   Accuracy_HKGrow =Accuracy_HKGrow + Conductance(A,Cluster_HKGrow)
   Size_Cluster_HKGrow_vec(j) = length(Cluster_HKGrow);

    % ========== Find Cluster with LOSP++ algorithm ========== %
    tic
    Cluster_LOSP_Plus = LOSP_Clustering(A,WalkMode,d,2,alpha,n0,Gamma10);
    time_LOSP_Plus = toc;
   %Accuracy_LOSP_Plus =Accuracy_LOSP_Plus +Accuracy_Score(Cluster_LOSP_Plus,TrueCluster)
   Accuracy_LOSP_Plus =Accuracy_LOSP_Plus + Conductance(A,Cluster_LOSP_Plus)
   Size_Cluster_LOSP_Plus_vec(j) = length(Cluster_LOSP_Plus);
end

mean_Size_Cluster_SSSCP = mean(Size_Cluster_SSCP_vec)
mean_Size_Cluster_ESSC = mean(Size_Cluster_ESSC_vec)
mean_Size_Cluster_HKGrow = mean(Size_Cluster_HKGrow_vec)
mean_Size_Cluster_LOSP_Plus = mean(Size_Cluster_LOSP_Plus_vec)

std_Size_Cluster_SSSCP = std(Size_Cluster_SSCP_vec)
std_Size_Cluster_ESSC = std(Size_Cluster_ESSC_vec)
std_Size_Cluster_HKGrow = std(Size_Cluster_HKGrow_vec)
std_Size_Cluster_LOSP_Plus = std(Size_Cluster_LOSP_Plus_vec)

% ================== Divide Conductance Scores by num_trials ========= %
Accuracy_SSCP = Accuracy_SSCP/num_trials
Accuracy_ESSC = Accuracy_ESSC/num_trials
Accuracy_HKGrow = Accuracy_HKGrow/num_trials
Accuracy_LOSP_Plus = Accuracy_LOSP_Plus/num_trials





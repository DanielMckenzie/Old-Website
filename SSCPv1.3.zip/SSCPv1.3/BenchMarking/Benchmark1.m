% =========================================== % 
% First benchmarking script - two unbalanced clusters
% Daniel Mckenzie
% 21 June 2018
% =========================================== %

clear, clc, close all
addpath(genpath('../ThirdParty'),genpath('../Utilities'),'../Functions')

% ============== Parameters ================= %
num_sizes = 5;                      % Number of different cluster sizes
num_trials = 5;                     % Number of trials to run for each size
Cluster_sizes = 100*[1:num_sizes];  % Vector of cluster sizes
k = 2;                              % Number of clusters, for generating SBM


% ============ Parameters for various algorithms ========== %
% === for SSSCP
epsilon = 0.2;
reject = 0.7;
sample_frac = 0.02;  % fraction of True Cluster to sample 
% === for LOSP_Plus
alpha = 0.1;         % random walk diffusion parameter
WalkMode = 2;        % type of random walk for LOSP++
d = 2;               % dimension of local spectral subspace
kk = 2;              % number of random walk steps


% ============== Define all vectors of interest =========== %
time_SSCP_vec = zeros(num_sizes,1);
time_HKGrow_vec = zeros(num_sizes,1);
time_LOSP_Plus_vec = zeros(num_sizes,1);
time_ESSC_vec = zeros(num_sizes,1);

Jaccard_SSCP_vec = zeros(num_sizes,1);
Jaccard_HKGrow_vec = zeros(num_sizes,1);
Jaccard_ESSC_vec = zeros(num_sizes,1);
Jaccard_LOSP_Plus_vec = zeros(num_sizes,1);

for j = 1:num_sizes
    n0 = Cluster_sizes(j);
    n1 = 10*Cluster_sizes(j);
    n0vec = [n0,n1];
    n = n0+n1;
    P = [3*log(n)^2/n, log(n)/n; log(n)/n, 3*log(n)^2/n];
    % =================== Reset all counters ================= %
    time_SSCP = 0;
    time_ESSC = 0;
    time_HKGrow = 0;
    time_LOSP_Plus = 0;
   
    Jaccard_SSCP = 0;
    Jaccard_ESSC = 0;
    Jaccard_HKGrow = 0;
    Jaccard_LOSP_Plus = 0;
    
    for i = 1:num_trials
        A = generateA2(n0vec,P);
        Im1 = mat2gray(full(A));
        perm = randperm(n);
        A = A(perm,perm);
        
        % =============== Find ground truth Cluster ================ %
        [~,permInv] = sort(perm);
        TrueCluster = permInv(1:n0);
        
        % ============== Extract Two sets of Seed vertices ========== %
        Gamma1 = datasample(TrueCluster,1,'Replace',false);
        Gamma2 = datasample(TrueCluster,ceil(sample_frac*n0),'Replace',false);
        Gamma10 = datasample(TrueCluster,10,'Replace',false);
        Gam_NBD = find(A(Gamma1,:));
        
        % ========== Find Cluster with SSSCP, many seeds ============ %
        tic
        Cluster_SSCP_Gam_2 = SSCPMain(A,Gamma2,n0,epsilon,reject);
        time_SSCP = time_SSCP + toc;
        Jaccard_SSCP = Jaccard_SSCP + Jaccard_Score(TrueCluster,Cluster_SSCP_Gam_2)
        
              
        % ========== Find Cluster with ESSC algorithm ============ %
       if n0 <= 200
           tic
           Cluster_ESSC  = ESSC(A,Gam_NBD,0.05);
           time_ESSC = time_ESSC + toc;
           Jaccard_ESSC = Jaccard_ESSC + Jaccard_Score(TrueCluster,Cluster_ESSC)
       end
        
        
        % ========== Find Cluster with HKGrow algorithm ========= %
        tic
        [Cluster_HKGrow,~,~,~] = hkgrow(A,Gamma2);
        time_HKGrow = time_HKGrow + toc;
        Jaccard_HKGrow = Jaccard_HKGrow + Jaccard_Score(TrueCluster,Cluster_HKGrow)
        
        % ========== Find Cluster with LOSP++ algorithm ========== %
        tic
        Cluster_LOSP_Plus = LOSP_Clustering(A,WalkMode,d,kk,alpha,n0,Gamma2);
        time_LOSP_Plus = toc;
        Jaccard_LOSP_Plus = Jaccard_LOSP_Plus + Jaccard_Score(TrueCluster,Cluster_LOSP_Plus)
    end
        
    time_SSCP_vec(j) = time_SSCP/num_trials;
    time_ESSC_vec(j) = time_ESSC/num_trials;
    time_HKGrow_vec(j) = time_HKGrow/num_trials;
    time_LOSP_Plus_vec(j) = time_LOSP_Plus/num_trials;
   
    Jaccard_SSCP_vec(j) = Jaccard_SSCP/num_trials;
    Jaccard_ESSC_vec(j) = Jaccard_ESSC/num_trials;
    Jaccard_HKGrow_vec(j) = Jaccard_HKGrow/num_trials;
    Jaccard_LOSP_Plus_vec(j) = Jaccard_LOSP_Plus/num_trials;
end


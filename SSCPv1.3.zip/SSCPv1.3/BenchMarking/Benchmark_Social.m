% =========================================== % 
% Benchmarking SSSCP for social networks
% Daniel Mckenzie
% 20 June 2018
% =========================================== %

clear, clc, close all
addpath(genpath('../ThirdParty'),genpath('../Utilities'),'../Functions')
addpath('../../facebook100')

% ============ Parameters for various algorithms ========== %
% === for SSSCP
delta = 0.2;
reject = 0.7;
sample_frac = 0.05;  % fraction of True Cluster to sample 
% === for LOSP_Plus
alpha = 0.1;         % random walk diffusion parameter
WalkMode = 2;        % type of random walk for LOSP++
d = 2;               % dimension of local spectral subspace
kk = 2;              % number of random walk steps


%load('Caltech36.mat')
%load('Rice31.mat')
load('UCSC68.mat')
%load('Smith60.mat')
Dormitories = local_info(:,5);
Dorm_IDs = unique(Dormitories);
ktemp = length(Dorm_IDs);
num_trials = 10;

%TrueClusters = cell(k,1);
k=0;
for j = 1:ktemp
    TempClust = find(Dormitories == Dorm_IDs(j));
    if length(TempClust) > 10
        k = k+1;
        TrueClusters{k} = TempClust;
    end
end

% Note that the first cluster always corresponds to vertices without a
% residence assignment, so we ignore it.

ClusterSizes = zeros(k-1,1);
for j = 1:k-1
    ClusterSizes(j) = length(TrueClusters{j+1});
end
MaxClusterSize = max(ClusterSizes);
MinClusterSize = min(ClusterSizes);
MeanClusterSize = mean(ClusterSizes);

disp(['The max cluster size is ',num2str(MaxClusterSize),' ,the min cluster size is ', ...
    num2str(MinClusterSize), ' and the mean cluster size is ', num2str(MeanClusterSize)])
    
% ============== Define all vectors of interest =========== %
time_SSSCP_vec = zeros(k-1,1);
time_Spectral_vec = zeros(k-1,1);
time_GenLouvain_vec = zeros(k-1,1);
time_HKGrow_vec = zeros(k-1,1);
time_LOSP_Plus_vec = zeros(k-1,1);
time_ZLZ_vec = zeros(k-1,1);
time_ESSC_vec = zeros(k-1,1);
Jaccard_SSSCP_vec = zeros(k-1,1);
Jaccard_Spectral_vec = zeros(k-1,1);
Jaccard_GenLouvain_vec = zeros(k-1,1);
Jaccard_ZLZ_vec = zeros(k-1,1);
Jaccard_HKGrow_vec = zeros(k-1,1);
Jaccard_ESSC_vec = zeros(k-1,1);
Jaccard_LOSP_Plus_vec = zeros(k-1,1);
num_Spectral_Failures_vec = zeros(k-1,1);

for i = 2:k
    % =============== Quantities of Interest ============= %
    Jaccard_SSSCP = 0;
    Jaccard_GenLouvain = 0;
    Jaccard_Spectral = 0;
    Jaccard_ZLZ = 0;
    Jaccard_ESSC = 0;
    Jaccard_LOSP_Plus = 0;
    Jaccard_HKGrow = 0;

    time_SSSCP = 0;
    time_GenLouvain = 0;
    time_Spectral = 0;
    time_ZLZ = 0;
    time_ESSC = 0;
    time_LOSP_Plus = 0;
    time_HKGrow = 0;
    TrueCluster = TrueClusters{i};
    n0 = length(TrueCluster);
    
    for j = 1:num_trials
        % ================ Draw Seed sets =============== %
        Gamma3 = datasample(TrueCluster,ceil(sample_frac*n0),'Replace',false);
        Gamma10 = datasample(TrueCluster,10,'Replace',false);
        Degs_in_cluster = sum(A(TrueCluster,:),2);
        [~,Gamma1] = max(Degs_in_cluster); 
        Gam_NBD = find(A(Gamma1,:));


        % ================= SSSCP ================= %
        tic
        Cluster_SSSCP = SSSCPMain(A,Gamma3,n0,delta,reject);
        time_SSSCP = time_SSSCP + toc;
        Jaccard_SSSCP = Jaccard_SSSCP + Jaccard_Score(TrueCluster,Cluster_SSSCP)

        % ============== ZLZ ==================== %
%           tic
%           Cluster_ZLZ  = ZLZ_Extraction(A,Gamma10,n0);
%           time_ZLZ = time_ZLZ + toc;
%           Jaccard_ZLZ = Jaccard_ZLZ + Jaccard_Score(TrueCluster,Cluster_ZLZ)

        % ============= ESSC ==================== %
           tic
           Cluster_ESSC  = ESSC(A,Gam_NBD,0.01);
           time_ESSC = time_ESSC + toc;
           Jaccard_ESSC = Jaccard_ESSC + Jaccard_Score(TrueCluster,Cluster_ESSC)

        % ================== HKGrow =================== %
        tic
        [Cluster_HKGrow,~,~,~] = hkgrow(A,Gamma3);
        time_HKGrow = time_HKGrow + toc;
        Jaccard_HKGrow = Jaccard_HKGrow + Jaccard_Score(TrueCluster,Cluster_HKGrow);

        % ========== Find Cluster with LOSP++ algorithm ========== %
        tic
        Cluster_LOSP_Plus = LOSP_Clustering(A,WalkMode,d,2,alpha,n0,Gamma3);
        time_LOSP_Plus = toc;
        Jaccard_LOSP_Plus = Jaccard_LOSP_Plus + Jaccard_Score(TrueCluster,Cluster_LOSP_Plus);
    end
    time_SSSCP_vec(i-1) = time_SSSCP/num_trials;
    time_Spectral_vec(i-1) = time_Spectral/num_trials;
    time_GenLouvain_vec(i-1) = time_GenLouvain/num_trials;
    time_ESSC_vec(i-1) = time_ESSC/num_trials;
    time_ZLZ_vec(i-1) = time_ZLZ/num_trials;
    time_HKGrow_vec(i-1) = time_HKGrow/num_trials;
    time_LOSP_Plus_vec(i-1) = time_LOSP_Plus/num_trials;
    Jaccard_SSSCP_vec(i-1) = Jaccard_SSSCP/num_trials;
    Jaccard_Spectral_vec(i-1) = Jaccard_Spectral/num_trials;
    Jaccard_GenLouvain_vec(i-1) = Jaccard_GenLouvain/num_trials;
    Jaccard_ESSC_vec(i-1) = Jaccard_ESSC/num_trials;
    Jaccard_ZLZ_vec(i-1) = Jaccard_ZLZ/num_trials;
    Jaccard_HKGrow_vec(i-1) = Jaccard_HKGrow/num_trials;
    Jaccard_LOSP_Plus_vec(i-1) = Jaccard_LOSP_Plus/num_trials;

end

av_time_SSSCP = mean(time_SSSCP_vec);
av_time_Spectral = mean(time_Spectral_vec);
av_time_GenLouvain = mean(time_GenLouvain_vec);
av_time_ESSC = mean(time_ESSC_vec);
av_time_ZLZ = mean(time_ZLZ_vec);
av_time_HKGrow = mean(time_HKGrow_vec);
av_time_LOSP_Plus = mean(time_LOSP_Plus_vec);
av_Jaccard_SSSCP = mean(Jaccard_SSSCP_vec);
av_Jaccard_Spectral = mean(Jaccard_Spectral_vec);
av_Jaccard_GenLouvain = mean(Jaccard_GenLouvain_vec);
av_Jaccard_ESSC = mean(Jaccard_ESSC_vec);
av_Jaccard_ZLZ = mean(Jaccard_ZLZ_vec);
av_Jaccard_HKGrow = mean(Jaccard_HKGrow_vec);
av_Jaccard_LOSP_Plus = mean(Jaccard_LOSP_Plus_vec);


% ============================================ %
% Testing effect of varying n_0 on the accuracy of SSCP
% Daniel Mckenzie
% 28 June 2018
% =========================================== %

clear, clc, close all
addpath(genpath('../ThirdParty'),genpath('../Utilities'),'../Functions')

n0true = 400;
n0_estimate_vec = [300,350,400,450,500];
num_sizes = length(n0_estimate_vec);
num_trials = 10;

% ============ Parameters for various algorithms ========== %
% === for SSSCP
epsilon = 0.2;
reject = 0.5;

sample_frac = 0.02;

% ============== Define all vectors of interest =========== %
time_SSCP_vec = zeros(num_sizes,1);
Jaccard_SSCP_vec = zeros(num_sizes,1);
Conductance_SSCP_vec = zeros(num_sizes,1);

for j = 1:num_sizes
    n1true = 10*n0true;
    %n1true = 9*n0true;
    n = n0true + n1true;
    P = [5*log(n)^2/n, log(n)/(2*n); log(n)/(2*n), log(n)/(2*n)];
    %P = [3*log(n)^2/n, log(n)/(n); log(n)/(n), 3*log(n)/(n)];
    %p = 3*(log(n))^2/n;
    %q = log(n)/n;
    
    % ================= Reset all counters ============== %
    Jaccard_SSCP = 0;
    time_SSCP = 0;
    Conductance_SSCP = 0;
    
    for i = 1:num_trials
        %A = generateA(n,n0true,p,q);
        A = generateA2([n0true,n1true],P);
        perm = randperm(n);
        A = A(perm,perm);
        
        % =============== Find ground truth Cluster ================ %
        [~,permInv] = sort(perm);
        TrueCluster = permInv(1:n0true);
        
        Gamma = datasample(TrueCluster,ceil(sample_frac*n0true),'Replace',false);
        
        tic
        Cluster_SSCP = SSCPMain(A,Gamma,n0_estimate_vec(j),epsilon,reject);
        time_SSCP = time_SSCP + toc;
        Jaccard_SSCP = Jaccard_SSCP + Jaccard_Score(TrueCluster,Cluster_SSCP);
        Conductance_SSCP = Conductance_SSCP + Conductance(A,Cluster_SSCP);
    end
    
    time_SSCP_vec(j) = time_SSCP/num_trials;
    Jaccard_SSCP_vec(j) = Jaccard_SSCP/num_trials;
    Conductance_SSCP_vec(j) = Conductance_SSCP/num_trials;
end
        
        
        
    
    
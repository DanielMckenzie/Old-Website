% Test the ESSC algorithm in matlab
% Daniel Mckenzie
% 7th May 2018
%

clear, close all, clc

% ============= Test on a synthetic data set ================= %
% addpath(genpath('../../Utilities'))
% n0 = 100;
% n1 = 2000;
% n0vec = [n0,n1];
% n = sum(n0vec);
% P = [0.1, 0.001; 0.001, 0.01];
% 
% A = generateA2(n0vec,P);
% perm = randperm(n);
% A = A(perm,perm);
% 
% [~,permInv] = sort(perm);
% TrueCluster = permInv(1:n0);


% ============== Test on a facebook data set ================= %
addpath('../../../facebook100')
%load('Caltech36.mat')
%load('Smith60.mat')
Dormitories = local_info(:,5);
Dorm_IDs = unique(Dormitories);
ktemp = length(Dorm_IDs);
num_trials = 10;

%TrueClusters = cell(k,1);
k=1;
for j = 1:ktemp
    TempClust = find(Dormitories == Dorm_IDs(j));
    if length(TempClust) > 10
        TrueClusters{k} = TempClust;
        k = k+1;
    end
end

TrueCluster = TrueClusters{3};

% ============== Parameters ================= %


Gamma5 = datasample(TrueCluster,5,'Replace',false);
Degs_in_cluster = sum(A(TrueCluster,:),2);
[~,Gamma1] = max(Degs_in_cluster); 
Gam_NBD = find(A(Gamma1,:));
Cluster_ESSC  = ESSC(A,Gam_NBD,0.05);
Jac_Score = Jaccard_Score(TrueCluster,Cluster_ESSC)


function C = ESSC(A,B0,alpha)
%        C = ESSC(A,B0,alpha)
% A matlab version of the ESSC algorithm
%
%

j = 0;
MaxJ = 50;
degrees = sum(A,2);
n = size(A,1);
B1 = [];

while (isequal(B0,B1) == 0 && j < MaxJ)
    j = j+1;
    
    if j > 1
        B0 = B1;
    end
    duBs = sum(A(:,B0),2);
    pB = sum(degrees(B0))/sum(degrees); % probability of a connection to B
    pvals = 1-cdf('Binomial',duBs,degrees,pB);
    [~,rank] = sort(pvals);
    pvals_bh = n*pvals./rank;
    if sum(pvals_bh) <= alpha
        B1 = [];
        return
    end
    threshold = max(pvals(pvals <= alpha));
    B1 = find(pvals <= threshold);
    if length(B1) < 1
        return
    end
end

if j == MaxJ
    disp('Max. iterations reached!')
end

C = B1;
end

        
    
    
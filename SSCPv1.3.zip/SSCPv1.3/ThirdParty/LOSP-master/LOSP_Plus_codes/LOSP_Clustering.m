function Cluster = LOSP_Clustering(A,WalkMode,d,k,alpha,n0,Gamma)
%        Cluster = LOSP_Clustering(WalkMode,d,k,alpha,beta)
% This is a simple implementation of the LOSP++ algorithm, presented in:
%       "Local Spectral Diffusion for Robust Community Detection"
%                       He, Shi, Hopcroft, Bindel
%                               SIGKDD 2016
% based on code downloaded from: https://github.com/KunHe2015/LOSP
% Daniel Mckenzie
% 19th June 2018
%
% INPUTS
% ===================================================================
% A ................ Adjacency matrix of graph
% WalkMode ......... 1=standard, 2=light lazy, 3=lazy, 4=personalized
% d ................ dimension of local spectral subspace
% k ................ number of random walk steps
% alpha ............ a parameter of random walk diffusion
% n0 ............... Required size of the community
% Gamma ............ Set of seed vertices
%
% OUTPUTS
% ===================================================================
% Cluster ......... The Cluster found
%

% Grab subgraph from each seed set
sample = SampleGraph(Gamma,A);


% Preprocessing, delete isolated nodes
subgraph = A(sample,sample);
idx = find(sum(subgraph)==0);

if length(idx) > 0
    sample = setdiff(sample,sample(idx));
end

% Approximate local spectral subspace
subgraph = A(sample,sample);
p = zeros(1,length(sample));
[~, ind] = intersect(sample,Gamma);
p(ind) = 1/length(ind);

% Local spectral subspace built on Nrw^T
V = Walk(subgraph,p,d,k,WalkMode,alpha);

% Get sparse vector by linear programming
v = pos1norm(V,ind);

% Bound detected community by target community size n0
if length(sample) < n0
    Cluster = sample;
else
    [~,I] = sort(v,'descend');
    Cluster = sample(I(1:n0));
end

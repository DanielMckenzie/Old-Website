function Cluster = SSCPMain(A,Gamma,n0,epsilon,reject)
%        Cluster = SSCPMain(A,Gamma,n0,delta,reject)
% This function performs Semi-Supervised Single Cluster Pursuit to find a
% single cluster.

% INPUT
% =================================
% A .................... Adjacency matrix of data converted to graph form.
% Gamma ................ VECTOR. Labelled data within cluster of interest
% n0 ................... (estimated) size of C_a
% epsilon ......... Omega_a will be of size (1+epsilon)n0(a)
% reject ....... value of threshold for ClusterPursuit
% OUTPUT
% ================================
% Cluster...... VECTOR. The elements in the cluster of interest.
%
% Daniel Mckenzie
% 30 April 2018
%

% ========= Initialization ================= %
n = size(A,1); % number of vertices
Dinv = spdiags(1./sum(A,2),0,n,n);
DinvA = Dinv*A;
L = speye(n,n) - DinvA;

Omega = OmegaThreshPlus2(DinvA,Gamma,n0,epsilon,n);
[Cluster,~] = ClusterPursuit(L,Gamma,Omega,n0,reject);
end
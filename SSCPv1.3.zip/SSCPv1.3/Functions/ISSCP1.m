function Clusters = ISSCP1(A,Gamma,n0vec,epsilon,reject,Assign_All)
%        Clusters = ISSCP1(A,Gamma,n0vec,delta)
% This function iterates the SSCP function to find clusters of sizes
% specified by n0vec. It allows for overlapping clusters. If Assign_All is
% set to 1, a final, clean up, step is also performed. This takes all
% vertices that have not yet been assigned to at least one cluster, and
% assigns them to the cluster containing the largest number of their
% neighbors.
%
% This version is NOT PARTITIONAL. That is, vertices can be assigned to
% multiple clusters. If this is not desired, use ISSCP2 instead.
%
% INPUT
% =================================
% A .................... Adjacency matrix of data converted to graph form.
% Gamma ......... CELL. Gamma{a} is labelled data within C_a
% n0vec ............ VECTOR. n0vec(a) is the (estimated) size of C_a
% epsilon ......... Omega_a will be of size (1+epsilon)n0vec(a)
% reject ....... value of threshold for ClusterPursuit
% Assign_All ........ logical, either 0 or 1. 
% OUTPUT
% ================================
% Clusters...... CELL. Clusters{a} = C_a
%
% Daniel Mckenzie
% 02 February 2018
%

% ========= Initialization ================= %
n = size(A,1); % number of vertices
k = length(n0vec); %number of clusters
Dinv = spdiags(1./sum(A,2),0,n,n);
DinvA = Dinv*A;
L = speye(n,n) - DinvA;
Clusters = cell(k,1);

% ===== Find the individual clusters using SCP =========== %
for a = 1:k
    Omega = OmegaThreshPlus2(DinvA,Gamma{a},n0vec(a),epsilon,n);
    [C,~] = ClusterPursuit(L,Gamma{a},Omega,n0vec(a),reject);
    Clusters{a} = C;
end
    

% ===== Classify the Leftovers (optional) ============ %
if Assign_All == 1
    [ClustersFinal,~,~] = CleanUp2(A,Clusters);
    Clusters = ClustersFinal;
end

end
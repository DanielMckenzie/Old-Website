function Omega = OmegaThreshPlus2(DinvA,Gamma,n0,epsilon,n)
%        Omega = OmegaThreshPlus2(DinvA,Gamma,n0,epsilon,n)
% This function determines the superset Omega needed for SSSCP
% by thesholding using the SIGNLESS Laplacian. Incorporates several 
% modifications for speed.
% INPUT
% ================================
% DinvA ............. A is Adj. mat. D is degree matrix. DinvA = Dinv*A
% Gamma ......... Labelled data/ seed vertices
% n0 ............ (estimated) size of cluster of interest
% epsilon ......... Omega will be of size (1+epsilon)n0
%
% OUTPUT
% ================================
% Omega ......... a set of vertices such that union(Omega, Gamma) 
% should contain C_1 
% L ............. The graph signless Laplacian
%
% Daniel Mckenzie
% 06 February 2018
% 

% ============= Start Up ============= %
g = length(Gamma); % Number of labelled data points
GammaC = setdiff(1:n,Gamma); % Complement of Gamma

% ========= Make the signless Laplacian etc ======= %
Lplus = speye(n,n) + DinvA;
bg = sum(Lplus(:,Gamma),2)'; 

% ============ Thresholding Step =========== %
v = bg*Lplus(:,GammaC);
[w,IndsThresh] = sort(v,'descend');
FirstZero = find(w==0, 1, 'first');
if ~isempty(FirstZero) && FirstZero < ceil((1+epsilon)*(n0)-g)
    warning('the size of Omega is smaller than (1+delta) times the user specified cluster size. You either need to specify a smaller size, or choose more seed vertices. Results from here on in may be unreliable')
    T = FirstZero;
else
    T = ceil((1+epsilon)*(n0)-g);
end
Omega = GammaC(IndsThresh(1:T));

end
function [Clusters,ClustersFinal] = ISSCP2(A,Gamma,n0vec,epsilon,reject)
%        Clusters = ISSCP2(A,Gamma,n0vec,delta,reject,weight))
% This function iterates the SSCP function to find clusters of sizes
% specified by n0vec. It does not allow for overlaps as it removes the 
% i-th cluster before attempting to find the (i+1)-st cluster. 
%
% This version IS PARTITIONAL. That is, every vertex is assigned to
% precisely one cluster.
%
% 19 April 2018
%
% INPUT
% =================================
% A .................... Adjacency matrix of data converted to graph form.
% Gamma ......... CELL. Gamma{a} is labelled data within C_a
% n0vec ............ VECTOR. n0vec(a) is the (estimated) size of C_a
% epsilon ......... Omega_a will be of size (1+epsilon)n0vec(a)
% reject ....... value of threshold for ClusterPursuit
%
% OUTPUT
% ================================
% Clusters ...... CELL. Clusters{a} = C_a before applying CleanUp
% ClustersFinal ....... CELL. ClustersFinal{a} = C_a after applying
% CleanUp.

% Note that the CleanUp sub-routine corresponds to the optional step 4 in
% the pseudocode description given in the accompanying paper. If there are
% background vertices present (i.e. vertices that should not be placed in
% any cluster) use Clusters instead of ClustersFinal.
%
% Daniel Mckenzie
% 02 February 2018
%

% ========= Initialization ================= %
Aold = A;
n = size(A,1); % number of vertices
N = n; % number of vertices, immutable
k = length(n0vec); %number of clusters
Clusters = cell(k,1);
Remaining = cell(k,1);
OmegaCell = cell(k,1);

% ============ Now iteratively find the clusters ============ %
for a=1:k-1
    % ====== Now run through the main SCP algorithm ====== %
    Dinv = spdiags(1./sum(A,2),0,n,n);
    DinvA = Dinv*A;
    L = speye(n,n) - DinvA;
    Omega = OmegaThreshPlus2(DinvA,Gamma{a},n0vec(a),epsilon,n);
    OmegaCell{a} = Omega;
    [C,~] = ClusterPursuit(L,Gamma{a},Omega,n0vec(a),reject);
    Remaining{a} = setdiff(1:n,C);
    if a ~=1
        for b = a-1:-1:1 
            Remtemp = Remaining{b};
            Ctemp = Remtemp(C);
            C = Ctemp;
        end
    end
    Clusters{a} = C;
    % also need to readjust the indices of the labeled sets Gamma_b
    for b = a+1:k-1
        Gamtemp = find(ismember(Remaining{a},Gamma{b}));
        Gamma{b} = Gamtemp';
    end
    A = A(Remaining{a},Remaining{a});
    clear Dinv DinvA L C
    n = size(A,1);
end

% ================= Extract the final cluster ====================== %
Dinv = spdiags(1./sum(Aold,2),0,N,N);
DinvA = Dinv*Aold;
L = speye(N,N) - DinvA;
Omega = setdiff(1:N,Cell2Vec(Clusters(1:k-1)));
[C,~] = ClusterPursuit(L,Gamma{k},Omega,n0vec(k),reject);
C = setdiff(C,Cell2Vec(Clusters(1:k-1)));  % remove any previously classified vertices that may have snuck back in
Clusters{k} = C;

% ================ Do a final sweep and classify the leftovers ========== %
[ClustersFinal,~,~] = CleanUp2(Aold,Clusters);

end

    
            
            
        
    
